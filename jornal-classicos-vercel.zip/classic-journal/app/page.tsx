import Front from '../components/Front';import {getContent} from '../lib/queries';
export const revalidate=0;export default async function Home(){const content=await getContent();return <Front {...content}/>}
