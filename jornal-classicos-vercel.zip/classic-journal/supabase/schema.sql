-- Execute no SQL Editor do seu projeto Supabase.
create extension if not exists pgcrypto;
create table if not exists public.admins(user_id uuid primary key references auth.users(id) on delete cascade);
create table if not exists public.editions(id uuid primary key default gen_random_uuid(),title text not null,month integer not null check(month between 1 and 12),year integer not null,number integer not null,cover_image text default '',published boolean not null default false,unique(month,year),unique(number));
create table if not exists public.articles(id uuid primary key default gen_random_uuid(),slug text not null unique,title text not null,subtitle text not null default '',body text not null default '',image text not null default '',caption text not null default '',category text not null default 'Notícias',brand text not null default '',model text not null default '',year integer not null default 1970,edition_id uuid references public.editions(id) on delete set null,published boolean not null default false,featured boolean not null default false,views integer not null default 0,created_at timestamptz not null default now());
create index if not exists articles_edition_idx on public.articles(edition_id);
alter table public.admins enable row level security;
alter table public.editions enable row level security;
alter table public.articles enable row level security;
create policy "admins can read own status" on public.admins for select to authenticated using (user_id=(select auth.uid()));
create policy "public reads published editions" on public.editions for select to anon,authenticated using(published or exists(select 1 from public.admins where user_id=(select auth.uid())));
create policy "admins manage editions" on public.editions for all to authenticated using(exists(select 1 from public.admins where user_id=(select auth.uid()))) with check(exists(select 1 from public.admins where user_id=(select auth.uid())));
create policy "public reads published articles" on public.articles for select to anon,authenticated using((published and exists(select 1 from public.editions e where e.id=edition_id and e.published)) or exists(select 1 from public.admins where user_id=(select auth.uid())));
create policy "admins manage articles" on public.articles for all to authenticated using(exists(select 1 from public.admins where user_id=(select auth.uid()))) with check(exists(select 1 from public.admins where user_id=(select auth.uid())));
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('article-images','article-images',true,10485760,array['image/jpeg','image/png','image/webp','image/gif']) on conflict(id) do nothing;
create policy "public reads images" on storage.objects for select to anon,authenticated using(bucket_id='article-images');
create policy "admins upload images" on storage.objects for insert to authenticated with check(bucket_id='article-images' and exists(select 1 from public.admins where user_id=(select auth.uid())));
create policy "admins update images" on storage.objects for update to authenticated using(bucket_id='article-images' and exists(select 1 from public.admins where user_id=(select auth.uid()))) with check(bucket_id='article-images' and exists(select 1 from public.admins where user_id=(select auth.uid())));
create policy "admins delete images" on storage.objects for delete to authenticated using(bucket_id='article-images' and exists(select 1 from public.admins where user_id=(select auth.uid())));
-- Incremento de visualizações sem conceder escrita direta à tabela.
create or replace function public.increment_article_views(article_uuid uuid) returns integer language plpgsql security definer set search_path = '' as $$ declare result integer; begin update public.articles a set views=a.views+1 where a.id=article_uuid and a.published and exists(select 1 from public.editions e where e.id=a.edition_id and e.published) returning a.views into result; return result; end $$;
revoke all on function public.increment_article_views(uuid) from public;
grant execute on function public.increment_article_views(uuid) to anon,authenticated;
-- Após criar o usuário em Authentication > Users, conceda o papel admin manualmente:
-- insert into public.admins(user_id) values ('UUID_DO_USUARIO');
