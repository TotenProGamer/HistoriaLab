# Gazeta Clássica
Jornal digital mensal de carros antigos em Next.js + Supabase.

## Iniciar
1. Instale Node.js 20+ e execute `npm install`.
2. Para ver a edição fictícia de demonstração, execute `npm run dev` sem configurar Supabase.
3. Crie um projeto em https://supabase.com e execute `supabase/schema.sql` no SQL Editor.
4. Em Authentication > Users, crie seu usuário com e-mail e senha. Depois copie o UUID e execute `insert into public.admins(user_id) values ('SEU_UUID');` no SQL Editor.
5. Copie `.env.example` para `.env.local`, preencha URL e chave pública do Supabase. Nunca exponha service_role.
6. Execute `npm run dev`, abra `/login`, entre e crie a primeira edição e matérias.
7. Envie a pasta ao GitHub, importe o repositório na Vercel, configure as duas variáveis de ambiente e faça Deploy.

## Importante
- Sem variáveis Supabase, a página pública usa matérias fictícias e o painel fica desativado.
- Com Supabase configurado, os dados são reais e a edição mais recente publicada aparece automaticamente. Não são inseridas notícias fictícias no banco.
- Imagens enviadas pelo administrador ficam no bucket público `article-images`. Não envie imagens privadas.
- O editor usa Markdown para negrito, itálico, títulos, listas, links e imagens; o HTML inserido no texto é ignorado.
- As permissões são aplicadas por RLS no banco e o acesso a `/admin` é conferido no servidor.
- Os contadores de visualização são incrementos simples, não visualizações únicas; para produção com tráfego elevado, adicione limitação de taxa e proteção contra bots.
- O nome e o logotipo atuais ficam no componente `components/Header.tsx`; personalização deles pelo painel ainda não está implementada.
- Os eventos não têm calendário estruturado, mas podem ser publicados como matérias na categoria Eventos.
