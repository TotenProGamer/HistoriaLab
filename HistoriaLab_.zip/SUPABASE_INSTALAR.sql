-- HISTÓRIALAB · Supabase SQL (execute uma única vez no SQL Editor)
-- ATENÇÃO: autenticação com nickname e senha, sem e-mail recuperável.
-- Desative Confirm email em Authentication > Providers > Email.
-- Não coloque a service_role key no navegador.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text not null,
  is_admin boolean not null default false,
  created_at timestamptz not null default now(),
  last_login_at timestamptz,
  last_seen_at timestamptz,
  quiz_best integer not null default 0 check (quiz_best between 0 and 10000),
  quiz_plays integer not null default 0 check (quiz_plays >= 0),
  quiz_last integer not null default 0 check (quiz_last between 0 and 10000),
  quiz_last_at timestamptz,
  geo_best integer not null default 0 check (geo_best between 0 and 10000),
  geo_plays integer not null default 0 check (geo_plays >= 0),
  geo_last integer not null default 0 check (geo_last between 0 and 10000),
  geo_last_at timestamptz,
  constraint nickname_valid check (char_length(nickname) between 3 and 18 and nickname ~ '^[[:alnum:]_-]+$')
);
create unique index if not exists profiles_nickname_ci_idx on public.profiles(lower(nickname));
create index if not exists profiles_last_seen_idx on public.profiles(last_seen_at desc);

create table if not exists public.login_events (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  logged_at timestamptz not null default now()
);
create index if not exists login_events_logged_at_idx on public.login_events(logged_at desc);
create index if not exists login_events_user_id_idx on public.login_events(user_id,logged_at desc);

create table if not exists public.campaign_state (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  completed integer[] not null default '{}',
  studied integer[] not null default '{}',
  updated_at timestamptz not null default now()
);

-- Cria o perfil automaticamente na criação do usuário no Supabase Auth.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v_nickname text;
begin
  v_nickname := trim(new.raw_user_meta_data->>'nickname');
  if v_nickname is null or char_length(v_nickname) not between 3 and 18
     or v_nickname !~ '^[[:alnum:]_-]+$' then
    raise exception 'Nickname inválido';
  end if;
  insert into public.profiles(id,nickname) values(new.id,v_nickname);
  return new;
end;
$$;
drop trigger if exists on_auth_user_created_historialab on auth.users;
create trigger on_auth_user_created_historialab
 after insert on auth.users for each row execute function public.handle_new_user();

-- Checagem de permissão de administrador executada no servidor.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists(select 1 from public.profiles p where p.id = (select auth.uid()) and p.is_admin = true);
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

alter table public.profiles enable row level security;
alter table public.login_events enable row level security;
alter table public.campaign_state enable row level security;

drop policy if exists profiles_read_self_or_admin on public.profiles;
create policy profiles_read_self_or_admin on public.profiles
 for select to authenticated using (id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists logins_admin_read on public.login_events;
create policy logins_admin_read on public.login_events
 for select to authenticated using ((select public.is_admin()));

drop policy if exists campaign_read_own on public.campaign_state;
create policy campaign_read_own on public.campaign_state
 for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists campaign_insert_own on public.campaign_state;
create policy campaign_insert_own on public.campaign_state
 for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists campaign_update_own on public.campaign_state;
create policy campaign_update_own on public.campaign_state
 for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

revoke all on public.profiles from anon,authenticated;
revoke all on public.login_events from anon,authenticated;
revoke all on public.campaign_state from anon,authenticated;
grant select on public.profiles to authenticated;
grant select on public.login_events to authenticated;
grant select,insert,update on public.campaign_state to authenticated;

-- Registra login sem permitir que um usuário falsifique outro user_id.
create or replace function public.record_login()
returns void language plpgsql security definer set search_path = '' as $$
declare v_user uuid := (select auth.uid());
begin
 if v_user is null then raise exception 'Autenticação necessária'; end if;
 update public.profiles set last_login_at=now(),last_seen_at=now() where id=v_user;
 insert into public.login_events(user_id) values(v_user);
end;
$$;
revoke all on function public.record_login() from public;
grant execute on function public.record_login() to authenticated;

-- Indicador aproximado de atividade; não registra IP ou localização.
create or replace function public.heartbeat()
returns void language plpgsql security definer set search_path = '' as $$
begin
 if (select auth.uid()) is null then raise exception 'Autenticação necessária'; end if;
 update public.profiles set last_seen_at=now() where id=(select auth.uid());
end;
$$;
revoke all on function public.heartbeat() from public;
grant execute on function public.heartbeat() to authenticated;

-- Salva recorde do usuário autenticado. Atenção: o jogo roda no cliente;
-- esta função valida limites, mas não garante prevenção completa contra trapaças.
create or replace function public.submit_score(p_mode text,p_points integer)
returns void language plpgsql security definer set search_path = '' as $$
begin
 if (select auth.uid()) is null then raise exception 'Autenticação necessária'; end if;
 if p_points is null or p_points < 0 or p_points > 10000 then raise exception 'Pontuação inválida'; end if;
 if p_mode = 'quiz' then
  update public.profiles set quiz_best=greatest(quiz_best,p_points),quiz_plays=quiz_plays+1,
    quiz_last=p_points,quiz_last_at=now(),last_seen_at=now() where id=(select auth.uid());
 elsif p_mode = 'geo' then
  update public.profiles set geo_best=greatest(geo_best,p_points),geo_plays=geo_plays+1,
    geo_last=p_points,geo_last_at=now(),last_seen_at=now() where id=(select auth.uid());
 else raise exception 'Modo inválido'; end if;
end;
$$;
revoke all on function public.submit_score(text,integer) from public;
grant execute on function public.submit_score(text,integer) to authenticated;

-- Ranking global só expõe nickname, pontuação e quantidade de partidas.
create or replace function public.get_leaderboard(p_mode text,p_limit integer default 20)
returns table(nickname text,best integer,played integer)
language plpgsql stable security definer set search_path = '' as $$
begin
 if (select auth.uid()) is null then raise exception 'Autenticação necessária'; end if;
 if p_mode not in ('quiz','geo') then raise exception 'Modo inválido'; end if;
 return query select p.nickname,
   case when p_mode='quiz' then p.quiz_best else p.geo_best end,
   case when p_mode='quiz' then p.quiz_plays else p.geo_plays end
 from public.profiles p
 where (case when p_mode='quiz' then p.quiz_plays else p.geo_plays end)>0
 order by (case when p_mode='quiz' then p.quiz_best else p.geo_best end) desc,p.created_at asc
 limit least(greatest(coalesce(p_limit,20),1),100);
end;
$$;
revoke all on function public.get_leaderboard(text,integer) from public;
grant execute on function public.get_leaderboard(text,integer) to authenticated;

-- TORNE-SE ADMINISTRADOR: depois de cadastrar sua conta pelo jogo,
-- substitua SEU_NICK_AQUI pelo nickname que você escolheu e execute:
-- update public.profiles set is_admin=true where lower(nickname)=lower('SEU_NICK_AQUI');
-- IMPORTANTE: nunca permita que jogadores alterem is_admin pelo navegador.
