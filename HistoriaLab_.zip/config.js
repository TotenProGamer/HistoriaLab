// HISTÓRIALAB · configure apenas os dados PÚBLICOS do seu projeto Supabase.
// Project URL e Publishable key (ou anon public key) em Supabase > Project Settings > API.
// NUNCA cole aqui service_role, secret key ou senha de administrador.
window.HISTORIALAB_CONFIG = {
  supabaseUrl: 'https://udcirfqsorbbebzlmqee.supabase.co', // exemplo: 'https://abcdefghijk.supabase.co'
  supabaseAnonKey: 'sb_publishable_t4jPNxRlm2W7tAwnTSvtLA_K1T_JGok' // chave publicável do projeto
};
